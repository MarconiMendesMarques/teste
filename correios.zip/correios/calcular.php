<?php

require __DIR__.'/vendor/autoload.php';

// NOVA INSTANCIA DOS CORREIOS SEM CONTRATO
use \App\WebService\Correios;

$obCorreios = new Correios();

//DADOS PARA O CALCULO DO FRETE
$codigoServico      = Correios::SERVICO_PAC;
$cepOrigem          = "60131170";
$cepDestino         = "70730767";
$peso               = 1;
$formato            = Correios::FORMATO_CAIXA_PACOTE;
$comprimento        = 15;
$altura             = 15;
$largura            = 15;
$diametro           = 0;
$maoPropria         = false;
$valorDeclarado     = 0;
$avisoRecebimento   = false;



$frete = $obCorreios->calcularFrete($codigoServico,
                                    $cepOrigem,
                                    $cepDestino,
                                    $peso,
                                    $formato,
                                    $comprimento,
                                    $altura,
                                    $largura,
                                    $diametro,
                                    $maoPropria,
                                    $valorDeclarado,
                                    $avisoRecebimento);

echo "<pre>";
echo print_r($frete);
echo "</pre>";

